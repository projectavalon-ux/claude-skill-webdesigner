# Usage

## Best prompt pattern

Use the skill, then give:
- brand or business type
- target audience
- tone
- required pages or section
- preferred visual direction
- conversion goal

## Example

Use the webdesigner skill. Create a premium homepage structure for a luxury beauty salon in Romanian. Prioritize mobile-first design, elegant spacing, and strong booking CTAs.

## Recommended workflow

1. Ask for page structure
2. Ask for section copy
3. Ask for design refinement
4. Ask for implementation notes
5. Ask for final QA pass

## Good tasks

- homepage planning
- service page improvement
- CTA hierarchy improvement
- hero section redesign
- brand-aligned layout direction
- mobile UX review
- premium style system suggestions
