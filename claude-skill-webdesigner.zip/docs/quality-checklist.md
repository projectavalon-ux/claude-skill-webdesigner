# Quality Checklist

Before finalizing design guidance, check:

- Is the page goal obvious?
- Is the headline strong and clear?
- Is the first screen useful on mobile?
- Are the CTAs visible and well placed?
- Is spacing premium and consistent?
- Is the section order intentional?
- Does the advice sound generic?
- Does the design feel coherent with the brand?
- Is the layout realistically buildable?
- Does the output improve trust and clarity?
