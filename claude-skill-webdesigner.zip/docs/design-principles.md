# Design Principles

## 1. Mobile-first thinking
Every recommendation should remain strong on small screens.

## 2. Premium spacing
Spacing creates perceived quality. Crowded interfaces feel cheaper.

## 3. Clear hierarchy
Users should understand:
- what this page is
- why it matters
- what to do next

## 4. Controlled elegance
Luxury is restraint, not visual overload.

## 5. Narrative flow
Sections should feel intentional and sequential, not randomly stacked.

## 6. Conversion with taste
Encourage action without sounding aggressive or low-end.

## 7. Realistic implementation
Advice should translate into an actual website, not just design jargon.
