# Installation

## Option 1: Manual skill loading

1. Open your Claude workflow, wrapper, or skill routing layer.
2. Copy the full contents of `system-prompt.md`.
3. Load it only for relevant design tasks.

## Option 2: Programmatic skill registry

If your system supports skill routing:
- register `skill.json`
- use `system-prompt.md` as the active instruction payload
- map this skill to design, UX, layout, branding, landing-page, and website requests

## Recommended pattern

Use this skill together with:
- a code-generation skill for HTML/CSS/WordPress
- a copywriting skill for longer-form sales copy
- a QA skill for audit passes

## Important

Do not keep this skill permanently active for non-design tasks if you want to minimize token usage.
