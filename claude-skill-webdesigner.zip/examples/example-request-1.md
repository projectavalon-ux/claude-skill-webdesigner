# Example Request 1

Use the webdesigner skill. I need a premium homepage for a high-end nail salon. The site should feel feminine, elegant, and modern. The main goal is booking appointments. Please structure the homepage, suggest visual direction, and keep mobile optimization active.
